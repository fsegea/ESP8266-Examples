// *** Hardwarespecific defines ***

#define fontbyte(x) cfont.font[x]  
#define bitmapbyte(x) bitmap[x]

#define bitmapdatatype unsigned char*
